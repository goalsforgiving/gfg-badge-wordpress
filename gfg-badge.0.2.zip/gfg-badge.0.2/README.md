Goals for Giving Badge - WordPress Plugin
=========================================

A simple plugin that allows you to show your support for charity by adding a smart little badge or ribbon to your blog.

Currently in beta, you can select [Islington Giving](http://www.islingtongiving.org.uk/), [Hibbs Lupus Trust](http://www.hibbslupustrust.org) and [Oxfam](http://www.oxfam.org.uk/) to try the plugin out.

You can fully customise it by selecting:

* Type - Ribbon or Badge
* Side - Left or Right
* Position - Fixed or Absolute ( fixed = stuck to your browser window, Absolute = stuck on the page )

Please let us know your feedback at <mailto:info@goalsforgiving.com>

This plugin is an extension of [Goals for Giving Charity Fundraising platform](http://www.goalsforgiving.com)